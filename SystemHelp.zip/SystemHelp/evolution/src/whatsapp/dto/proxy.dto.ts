export class ProxyDto {
  enabled: boolean;
  proxy: string;
}
